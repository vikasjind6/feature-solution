(function () {

    'use strict';

    var app = angular.module("app", ['ngRoute']);

      app.controller('dashboardCtrl',['$scope','$location',function($scope,$location){
$scope.message="welcome";

      }]);
      app.controller('mainCtrl',['$scope','$location',function($scope,$location){

        $location.path('login');

      }]);
      app.controller('loginCtrl',['$scope','$location',function($scope,$location){
        $scope.user={}
        $scope.login=function(){
          if($scope.user.username=='admin' && $scope.user.password=='admin'){
              $scope.message="login successfully";
              $location.path('dashboard');
          }else if($scope.user.username!='admin' && $scope.user.password!='admin'){
              $scope.message="Invalid Credentials";
            }else if ($scope.user.username!="admin"){
            $scope.message="Invalid Username";
          }else if ($scope.user.password!="admin"){
            $scope.message="Invalid Password";
          }

        };


      }]);


    app.config(['$routeProvider',function($routeProvider){
      $routeProvider.
     when('/dashboard', {
       templateUrl: 'views/dashboard.html',
       controller: 'dashboardCtrl'
     }).
     when('/login', {
       templateUrl: 'views/login.html',
       controller: 'loginCtrl'
     }).
     when('/', {
       templateUrl: 'views/index.html',
       controller: 'mainCtrl'
     }).

     otherwise({
       redirectTo: '/'
     });

   }]);



})();
